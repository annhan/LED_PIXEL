LPD6803 Library
===============


## General Information
3 Channels, each channel support 32 grey scale levels,  maximal current per channel is 45mA, Built-In LDO voltage-stabilizing circuit, voltage range is 3-8v, and have 5V stabilizing
voltage output.


## Where to buy
I sell those square LPD6803 led modules at http://pixelinvaders.ch/


